import { Router } from "express";
import {
  createPurchase,
  getProducts,
  getPurchases,
} from "../controllers/product.controller";
import middleware from "../middleware/verify.middleware";

const router = Router();

router.post("/create", middleware, createPurchase);
router.get("/bulk", getProducts);
router.get("/purchase", middleware, getPurchases);

export default router;
